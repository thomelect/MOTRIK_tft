---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

### Feature Request or Enhancement
*Please describe what you would like to see GUIslice do*: ???

### Additional context
*Add any other context or screenshots about the feature request here.*
